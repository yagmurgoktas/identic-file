import hashlib
import os
import sys
from collections import deque
import argparse

namehash = {}  # creating dict of name hashes
contenthash = {}  # creating dict of content hashes

#parser for command line arguments
parser = argparse.ArgumentParser()
group = parser.add_mutually_exclusive_group()
group.add_argument('-f', '--fflag', action="store_true")
group.add_argument('-d', '--dflag', action="store_true")
parser.add_argument('-c', '--cflag', action="store_true")
parser.add_argument('-n', '--nflag', action="store_true")
parser.add_argument('-cn', '--cnflag', action="store_true")
parser.add_argument('-s', '--sflag', action="store_true")
parser.add_argument("dirss", nargs="*", default=".", type=str)

args = parser.parse_args()
#flags
f = False
d = False
c = False
n = False
cn = False
s = False

if args.fflag:
    f = True
if args.dflag:
    d = True
if args.cflag:
    c = True
if args.nflag:
    n = True
if args.cnflag:
    cn = True
    c=True
    n=True
if args.sflag:
    if c:
        s = True

#recursive function for finding hashes of contents of paths
def chashhh(strr):

    if strr in contenthash:

        return contenthash[strr]
    else:

        if not (os.path.isdir(strr)):

            f = open(strr, "rb")
            if f.readable():
                contents = f.read()


            contenthash[strr] = hashlib.sha256(contents).hexdigest()

        else:

            inside=[]
            for name in os.listdir(strr) :
                inside.append( os.path.join(strr,name))

            hashes=[]
            for r in inside:
                hashes.append(chashhh(r))

            hashes.sort()
            stir = ""
            for t in hashes:

                stir = stir + t
            contenthash[strr] = hashlib.sha256(stir.encode()).hexdigest()
        return contenthash[strr]

#recursive function for finding hashes of names of paths
def nhashhh(strr):
    a = strr.split('/')
    if strr in namehash:
        return namehash[strr]
    else:
        if not (os.path.isdir(strr)):
            kk=a[len(a) - 1]
            namehash[strr] = hashlib.sha256(kk.encode()).hexdigest()
        else:
            insidenames=[]
            for name in os.listdir(strr) :

                insidenames.append(os.path.join(strr,name))

            hashes=[]
            for r in insidenames:
                hashes.append(nhashhh(r))

            hashes.sort()
            kk=a[len(a) - 1]
            stir = hashlib.sha256(kk.encode()).hexdigest()
            for t in hashes:
                stir = stir + t
            namehash[strr] = hashlib.sha256(stir.encode()).hexdigest()
    return namehash[strr]
#prints the paths in list which contains identic files or directories
def printliste(liste):
    if len(liste) > 1:
        if s:
            for name in liste:
                print(os.path.abspath(name) + "\t" + str(os.stat(name).st_size))

        else:
            for name in liste:
                print(os.path.abspath(name))
        print("")
#using two nested for loops looking for identic files or directories by looking dictionary which are filled before with content hashes
def cfunc():

    for i  in contenthashh:
        listee=[i]
        contenthashh.remove(i)
        for j  in contenthashh:
            if ( i!=j) and (contenthash[i] == contenthash[j]):
                if d  and (f == False):
                    if os.path.isdir(i):
                            contenthashh.remove(j)
                            listee.append(j)

                elif (d == False and f == True) or (d == False and f == False):
                    if not (os.path.isdir(i)):
                            contenthashh.remove(j)
                            listee.append(j)

        printliste(listee)

#using two nested for loops looking for identic files or directories by looking dictionary which are filled before with name hashes
def nfunc():
   
    for i  in namehashh:
        listee=[i]
        namehashh.remove(i)
        for j  in namehashh:
            if ( i!=j) and (namehash[i] == namehash[j]):
                if d  and (f == False):
                    if os.path.isdir(i):
                        namehashh.remove(j)
                        listee.append(j)

                elif (d == False and f  ) or (d == False and f == False):
                    if not (os.path.isdir(i)):
                        namehashh.remove(j)
                        listee.append(j)

        printliste(listee)


#using two nested for loops looking for identic files or directories by looking dictionaries which are filled before with hashes
def cnfunc():
    for i in namehashh:
        listee=[i]
        for j in namehashh:
            if i!=j and ((namehash[i] == namehash[j]) and (contenthash[i] == contenthash[j] )):

                if d  and (f == False):
                    if os.path.isdir(i):
                        listee.append(j)

                elif (d == False) and f or d == False and f == False:
                    if not (os.path.isdir(i)):
                        listee.append(j)
        printliste(listee)


def Myfn(x):
    return  os.stat(x).st_size

#this part operates c flag looking for identic in terms of content
if (c and (not n)) or ((not c) and (not n)):
    qlist=[]
    for i in args.dirss:
        i=os.path.abspath(i)
        qlist.append(i)

        while qlist:
            currentdir = qlist[0]
            qlist.remove(qlist[0])

            chashhh(currentdir)

            dircontents = os.listdir(currentdir)

            for name in dircontents:

                currentitem = os.path.join(currentdir,name)

                if os.path.isdir(currentitem):
                    qlist.append(currentitem)
                else:
                    chashhh(currentitem)



    if s:
        contenthashh = sorted(contenthash.keys(), key=Myfn ,reverse=True )

    else:
        contenthashh = sorted(contenthash.keys())



    cfunc()
#this part operates cn flag looking for identic in terms of content
elif ((c and n) or cn):
    qlist=[]
    for i in args.dirss:
        i=os.path.abspath(i)
        qlist.append(i)

        while qlist:
            currentdir = qlist[0]
            qlist.remove(qlist[0])

            chashhh(currentdir)

            nhashhh(currentdir)

            dircontents = os.listdir(currentdir)
            for name in dircontents:
                currentitem = os.path.join(currentdir,name)

                if os.path.isdir(currentitem):
                    qlist.append(currentitem)
                else:
                    chashhh(currentitem)
                    nhashhh(currentitem)

    if s:
        namehashh = sorted(namehash.keys(), key=Myfn , reverse=True)
    else:
        namehashh = sorted(namehash.keys())


    cnfunc()

#this part operates n flag looking for identic in terms of content
elif ((not c) and n):
    qlist=[]
    for i in args.dirss:
        i=os.path.abspath(i)
        qlist.append(i)

        while qlist:

            currentdir = qlist[0]
            qlist.remove(qlist[0])

            nhashhh(currentdir)

            dircontents = os.listdir(currentdir)
            for name in dircontents:

                currentitem = os.path.join(currentdir,name)



                if os.path.isdir(currentitem):
                    qlist.append(currentitem)
                else:
                    nhashhh(currentitem)


    namehashh = sorted(namehash.keys())
    nfunc()



